<template>
    <div class="container">
        <section id="feature_category_section" class="feature_category_section category_page section_wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="feature_news_item">
                                    <div class="item">
                                        <div class="item_wrapper">

                                            <div class="item_img_background skeleton">

                                            </div>
                                            <!--item_img-->
                                            <div class="item_title_date">
                                                <div class="news_item_title">
                                                    <h2 class="skeleton">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2>
                                                </div>
                                                <div class="item_meta skeleton">&nbsp;&nbsp;</div>
                                            </div>
                                            <!--item_title_date-->
                                        </div>
                                        <!--item_wrapper-->
                                        <div class="item_content ">&nbsp;&nbsp;&nbsp;&nbsp;
                                        </div>
                                    </div>
                                    <!--item-->
                                </div>
                                <!--feature_news_item-->
                                <!--feature_news_item-->
                            </div>
                            <!--col-md-6-->
                        </div>
                    </div>
                    <!--col-md-9-->
                    <div class="col-md-3">
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!--feature_news_item-->
</template>
<script>
export default {
    name: 'Media4',
    created: function() {

    },
};

</script>

<template>
  <div class="" style="text-align:center;padding:100px; 0px;" >
    <h1 style="color:#808080">
    	Page Not found
    </h1>
  </div>
</template>

<script>
export default {
  name: "Error",
  mounted() {
  }
};
</script>

<style></style>

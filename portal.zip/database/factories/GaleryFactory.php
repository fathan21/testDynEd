<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Galery;
use Faker\Generator as Faker;

$factory->define(Galery::class, function (Faker $faker) {
    return [
        //
    ];
});

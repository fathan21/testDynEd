<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostsMeta extends Model
{
    //
    protected $table = 'posts_meta';
}

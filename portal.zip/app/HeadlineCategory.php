<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HeadlineCategory extends Model
{
    //
    protected $table = 'headline_category';
}

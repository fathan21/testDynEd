<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContentGalery extends Model
{
    //
    protected $table = 'content_galery';
}

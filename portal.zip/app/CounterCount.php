<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CounterCount extends Model
{
    //
    protected $table = 'counter_hits';
}

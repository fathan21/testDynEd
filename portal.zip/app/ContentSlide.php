<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContentSlide extends Model
{
    //
    protected $table = 'content_slide';
}
